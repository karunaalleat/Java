package challenges;

import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		
		List<Shape> shapes = new ArrayList<>();
		shapes.add(new Rectangle(10, 15));
		// rectangle with default constructor
		shapes.add(new Rectangle());
		shapes.add(new Triangle(15, 15));
		// Triangle with default constructor
		shapes.add(new Triangle());
		shapes.add(new Square(60));
		// Square with default constructor
		shapes.add(new Square());
		
		for(Shape shape : shapes) {
			System.out.println(shape.getShapeName());
		}
	}
}
