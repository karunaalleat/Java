package challenges;

public abstract class Shape {
	
	public abstract String getShapeName();

}
