package challenges;

public  class Triangle extends Shape {
	
	public int width;
    public int height;
    
 // add  default constructor
    public Triangle() {
    	this.width=20;
    	this.height=30;
    }
    
    public Triangle(int width, int height) {
    	// code to set your attribute
    	this.width = width;
    	this.height = height;
    }
	@Override
	public String getShapeName() {
		// TODO Auto-generated method stub
		return "Triangle";
	}

}
