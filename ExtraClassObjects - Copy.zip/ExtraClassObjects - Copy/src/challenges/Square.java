package challenges;

public class Square extends Shape {
	public int size;
	
	// add  default constructor
    public Square() {
    	this.size=50;
    }
	public Square(int size) {
		// code to set your attribute
		this.size = size;
	}
	@Override
	public String getShapeName() {
		// TODO Auto-generated method stub
		return "Square";
	}

}
